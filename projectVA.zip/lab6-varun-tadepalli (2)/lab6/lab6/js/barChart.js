/**
 * Assignment name: Lab 6 - bar chart
 * First name: Varun 
 * Last name:   Tadepalli
 * Student ID:  801365164
*/
class BarChart {
    
    /**
     * class constructor with basic chart configuration
     * @param {Object} _config 
     * @param {Array} _data 
     * @param {d3.Scale} _colorScale 
     */
    constructor(_config, _data, _colorScale) {
        this.config = {
            parentElement: _config.parentElement,
            containerWidth: _config.containerWidth || 500,
            containerHeight: _config.containerHeight || 140,
            margin: _config.margin || {top: 5, right: 5, bottom: 20, left: 50}
        };
        this.data = _data;
        this.colorScale = _colorScale;
        this.initVis();
    }
    
    /**
     * this function is used to initialize scales/axes and append static elements
     */
    initVis() {
        let vis = this;

        vis.width = vis.config.containerWidth - vis.config.margin.left - vis.config.margin.right;
        vis.height = vis.config.containerHeight - vis.config.margin.top - vis.config.margin.bottom;

        vis.svg = d3.select(vis.config.parentElement)
            .append('svg')
            .attr('width', vis.config.containerWidth)
            .attr('height', vis.config.containerHeight);
        
        vis.chart = vis.svg.append('g')
            .attr('transform', `translate(${vis.config.margin.left},${vis.config.margin.top})`);

        vis.xScale = d3.scaleBand()
            .range([0, vis.width])
            .paddingInner(0.2);
        
        vis.yScale = d3.scaleLinear()
            .range([vis.height, 0]); 

        vis.xAxis = d3.axisBottom(vis.xScale)
            .tickSizeOuter(0);

        vis.yAxis = d3.axisLeft(vis.yScale)
            .ticks(6)
            .tickSizeOuter(0);

        vis.xAxisG = vis.chart.append('g')
            .attr('class', 'axis x-axis')
            .attr('transform', `translate(0,${vis.height})`);

        vis.yAxisG = vis.chart.append('g')
            .attr('class', 'axis y-axis');

        vis.svg.append('text')
            .attr('class', 'axis-title')
            .attr('x', 0)
            .attr('y', 0)
            .attr('dy', '.71em')
    }

    /**
     * this function is used to prepare the data and update the scales before we render the actual vis
     */
    updateVis() {
        let vis = this;

         vis.array = [];

        var data1= {}

        const writer = vis.data.filter(d => d.writer === 'Aaron Sorkin');

        for(let i=0;i<writer.length;i++)
        {
            
            data1 = { score : writer[i].score , director : writer[i].director}
            vis.array.push(data1)
            
        }

        console.log(vis.array,"arrayu")


        vis.x = d3.scaleBand()
        .range([0, vis.width])
        .padding(0.4);
     
       // Create a scale for the y-axis
       vis.y = d3.scaleLinear()
            .range([vis.height, 0]);

        console.log()


         vis.colorScale.domain(vis.array.map(function(d) { return d.director; }))
    
       
        vis.xScale.domain(vis.array.map(function(d, i) {return d.director; }));

        vis.yScale.domain([0, d3.max(vis.array, function(d) { return d.score; })]);

        vis.renderVis();
    }

    /**
     * this function contains the d3 code for binding data to visual elements
     */
    renderVis() {
        let vis = this;

        // Todos
        vis.chart.selectAll('.bar')
        .data(vis.array)
        .enter().append("rect")
        .attr('class', 'bar')
        .attr('x', (function(d) { return vis.xScale(d.director); }))
        .attr('y', (function(d) { return vis.yScale(d.score); }))
        .attr('width', vis.xScale.bandwidth())
        .attr("height", function(d) { return vis.height - vis.yScale(d.score); })
        .style("fill", function(d) { return vis.colorScale(d.director); })
        .on('click', function(event, d) {
        })
        
        .on('mouseover', function(event, d) {
            d3.selectAll('.line')
            .style('stroke-opacity', lineData => lineData.director === d.key ? 1 : 0.1);
            d3.select(this).attr('stroke', 'black') 
            .attr('stroke-width', 2); 

        })
        .on('mouseout',function(event,d){
            d3.select(this)
        .attr('stroke', 'none') 
        .attr('stroke-width', '0');
            
        })
        
        .on('click',function(event,d){
            const filteredData = vis.data.filter(penguin => penguin.director === d.key);
            // Call update function of parallel coordinates visualization with filtered data
            //parallelCoordinatesVis.updateVis(filteredData);
            d3.select(this)
            .attr('stroke', 'black') 
            .attr('stroke-width', 2); 
            console.log(d.score)
            console.log(d.director)

            
        })


        vis.xAxisG.call(vis.xAxis);
        vis.yAxisG.call(vis.yAxis);
    }
}