// **
//  * Assignment name: Lab 6 - parallel coordinates
//  * First name: ram sai 
//  * Last name: nimmagadda
//  * Student ID: 801363716
// */
class ParallelCoordinates {
    
    /**
     * class constructor with basic chart configuration
     * @param {Object} _config 
     * @param {Array} _data 
     * @param {d3.Scale} _colorScale 
     */
    constructor(_config, _data, _colorScale) {
        this.config = {
            parentElement: _config.parentElement,
            containerWidth: _config.containerWidth || 500,
            containerHeight: _config.containerHeight || 500,
            margin: _config.margin || {top: 25, right: 20, bottom: 20, left: 35}
        };
        this.data = _data;
        this.colorScale = _colorScale;
        this.initVis();
    }

    /**
     * this function is used to initialize scales/axes and append static elements
     */
    initVis() {
        let vis = this;

        vis.width = vis.config.containerWidth - vis.config.margin.left - vis.config.margin.right;
        vis.height = vis.config.containerHeight - vis.config.margin.top - vis.config.margin.bottom;

        vis.svg = d3.select(vis.config.parentElement)
            .append('svg')
            .attr('width', vis.config.containerWidth)
            .attr('height', vis.config.containerHeight);
        
        vis.chart = vis.svg.append('g')
            .attr('transform', `translate(${vis.config.margin.left},${vis.config.margin.top})`);

        // Todo: initialize scales and axes
        
        var margin = {top: 30, right: 10, bottom: 10, left: 0};
        var width = vis.config.containerWidth - margin.left - margin.right;
        var height = vis.config.containerHeight - margin.top - margin.bottom;
        var dimensions = ['culmen_length_mm', 'culmen_depth_mm', 'flipper_length_mm', 'body_mass_g'];

        var y = {};
        dimensions.forEach(name => {
            y[name] = d3.scaleLinear()
                .domain(d3.extent(vis.data, d => +d[name]))
                .range([height, 0]);
        });

        var x = d3.scalePoint()
            .range([0, width])
            .padding(1)
            .domain(dimensions);

        // Define path function
        vis.path = d => d3.line()(dimensions.map(p => [x(p), y[p](d[p])]));

        // Todo: append axis groups
        dimensions.forEach(d => {
            vis.chart.append("g")
                .attr("class", "axis")
                .attr("transform", "translate(" + x(d) + ")")
                .each(function() {
                    d3.select(this).call(d3.axisLeft().scale(y[d]));
                });
        });
    

        // Todo: append axis titles (each axis should contain 1 title)
        dimensions.forEach((d, i) => {
            vis.chart.append("text")
                .style("text-anchor", "middle")
                .attr("y", -9)
                .attr("x", x(d))
                .text(d)
                .style("fill", "black");
        });


        vis.chart.selectAll(".line")
        .on('mouseover', function(event, d) {
        // Update opacity or fill-opacity for bars in bar chart
        d3.selectAll('.bar')
            .style('fill-opacity', barData => barData.key === d.species ? 1 : 0.1);
        });

        vis.chart.selectAll(".line")
        .on('mouseout', function(event, d) {
        // Reset opacity or fill-opacity for all bars in bar chart
        d3.selectAll('.bar')
            .style('fill-opacity', 1); // Reset opacity to original value
        });
    }


    /**
     * this function is used to prepare the data and update the scales before we render the actual vis
     */
    updateVis() {
        let vis = this;
    // Todo

    // Define keys for parallel coordinates
    vis.keys = ['culmen_length_mm', 'culmen_depth_mm', 'flipper_length_mm', 'body_mass_g'];

        vis.renderVis();
    }

    /**
     * this function contains the d3 code for binding data visual elements
     */
    renderVis() {
        let vis = this;
        // Draw the lines
        vis.chart.selectAll(".line")
        .data(vis.data)
        .enter().append("path")
        .attr("class", "line")
        .attr("d", d => vis.path(d)) // Utilize the path function defined in initVis()
        .style("fill", "none")
        .style("stroke", d => vis.colorScale(d.species))
        .style("opacity", 0.5)
        .on('mouseover', function(event, d) {
            d3.select(this).attr('stroke', 'black') 
            .attr('stroke-width', 2); 

        })
        .on('mouseout',function(event,d){
            d3.select(this)
        .attr('stroke', 'black') 
        .attr('stroke-width', '2');
            
        })
        // .on('click',function(event,d){
        //     d3.select(this)
        //     .attr('stroke', 'black') 
        //     .attr('stroke-width', 2); 

            
        // });
      

        // Draw the axis
        vis.chart.selectAll(".axis")
            .data(vis.keys)
            .enter().append("g")
            .attr("class", "axis")
            .attr("transform", (d, i) => `translate(${i * (vis.width / vis.keys.length)}, 0)`)
            .each(function(d) { d3.select(this).call(d3.axisLeft().scale(vis.y[d])); })
            .append("text")
            .style("text-anchor", "middle")
            .attr("y", -9)
            .text(d => d.replace(/_/g, " ")) // Replace underscores with spaces
            .style("fill", "black");
        
    }
    
}