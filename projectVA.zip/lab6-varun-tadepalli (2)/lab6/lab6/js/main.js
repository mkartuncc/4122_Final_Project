/**
 * Assignment name: Lab 6 - main
 * First name: Varun
 * Last name:   Tadepalli
 * Student ID:  801365164
*/
let data, barchart, parallelCoordinates,globalColours;

d3.csv('data/penguins_size.csv').then(_data => {

    data = _data;
    const keys = ['culmen_length_mm', 'culmen_depth_mm', 'flipper_length_mm', 'body_mass_g'];

    
    data.forEach(d => {
        d.score = +d.score;
    });

    //data = data.filter(d => !isNaN(d.score) && !isNaN(d.director) && !isNaN(d.writer));

    console.log(data)

    globalColours = d3.scaleOrdinal(d3.schemeCategory10);

    console.log(data)

    barchart = new BarChart({parentElement:'#barChart'},data,globalColours);
    barchart.updateVis();
    parallelCoordinates = new ParallelCoordinates({parentElement: '#parallelCoordinates'}, data, globalColours);
    parallelCoordinates.updateVis();
    


})
.catch(error => console.error(error));

// Todos